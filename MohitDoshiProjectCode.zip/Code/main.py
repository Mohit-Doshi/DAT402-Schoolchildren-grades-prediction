# MOHIT DOSHI
# 04/30/2021
# DAT 402


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.ensemble import GradientBoostingRegressor

from sklearn.datasets import make_regression
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.feature_selection import f_regression
from sklearn.model_selection import train_test_split

from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn import metrics
from sklearn.cluster import KMeans
from sklearn.naive_bayes import GaussianNB
from sklearn import tree

import torch
import torch.nn as nn
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler





math_scores = pd.read_csv('student-mat.csv')
portugese_scores = pd.read_csv('student-por.csv')

# print(math_scores.columns)
# print(portugese_scores.columns)


# Math scores first

# Plot for boys vs girls
num_boys = 0
num_girls = 0
genders = []
for score in math_scores['sex']:
    genders.append(score)
    if score == 'F':
        num_girls += 1
    else:
        num_boys += 1

print(num_boys)
print(num_girls)
print(genders)
# plt.hist(genders)
# plt.show()

avg_scores = []
Pcollegedegree = []
Pbothcollegedegree = []
for i in range(len(math_scores)):
    avg_scores.append((math_scores['G1'][i] + math_scores['G2'][i] + math_scores['G3'][i])/3)
    Pcollegedegree.append(1 if (math_scores['Medu'][i] == 4 or math_scores['Fedu'][i] == 4) else 0)
    Pbothcollegedegree.append(1 if (math_scores['Medu'][i] == 4 and math_scores['Fedu'][i] == 4) else 0)

print(avg_scores, '\n', Pcollegedegree)
# Feature Selection

# school - student's school (binary: 'GP' - Gabriel Pereira or 'MS' - Mousinho da Silveira)
# sex - student's sex (binary: 'F' - female or 'M' - male)
# age - student's age (numeric: from 15 to 22)
# address - student's home address type (binary: 'U' - urban or 'R' - rural)
# famsize - family size (binary: 'LE3' - less or equal to 3 or 'GT3' - greater than 3)
# Pstatus - parent's cohabitation status (binary: 'T' - living together or 'A' - apart)
# Medu - mother's education (numeric: 0 - none, 1 - primary education (4th grade), 2 – 5th to 9th grade, 3 – secondary education or 4 – higher education)
# Fedu - father's education (numeric: 0 - none, 1 - primary education (4th grade), 2 – 5th to 9th grade, 3 – secondary education or 4 – higher education)
# Mjob - mother's job (nominal: 'teacher', 'health' care related, civil 'services' (e.g. administrative or police), 'at_home' or 'other')
# Fjob - father's job (nominal: 'teacher', 'health' care related, civil 'services' (e.g. administrative or police), 'at_home' or 'other')
# guardian - student's guardian (nominal: 'mother', 'father' or 'other')
# traveltime - home to school travel time (numeric: 1 - 1 hour)
# studytime - weekly study time (numeric: 1 - 10 hours)
# failures - number of past class failures (numeric: n if 1<=n<3, else 4)
# schoolsup - extra educational support (binary: yes or no)
# famsup - family educational support (binary: yes or no)
# paid - extra paid classes within the course subject (Math or Portuguese) (binary: yes or no)
# activities - extra-curricular activities (binary: yes or no)
# nursery - attended nursery school (binary: yes or no)
# higher - wants to take higher education (binary: yes or no)
# internet - Internet access at home (binary: yes or no)
# romantic - with a romantic relationship (binary: yes or no)
# famrel - quality of family relationships (numeric: from 1 - very bad to 5 - excellent)
# freetime - free time after school (numeric: from 1 - very low to 5 - very high)
# goout - going out with friends (numeric: from 1 - very low to 5 - very high)
# Dalc - workday alcohol consumption (numeric: from 1 - very low to 5 - very high)
# Walc - weekend alcohol consumption (numeric: from 1 - very low to 5 - very high)
# health - current health status (numeric: from 1 - very bad to 5 - very good)
# absences - number of school absences (numeric: from 0 to 93)

X_og = []
y_og = avg_scores
og_cols = ['school', 'sex', 'age', 'address', 'famsize', 'Pstatus', 'Medu', 'Fedu', 'traveltime', 'studytime', 'failures', 'schoolsup', 'famsup', 'paid', 'activities', 'nursery', 'higher', 'internet', 'romantic', 'famrel', 'freetime', 'goout', 'Dalc', 'Walc', 'health', 'absences']

for i in range(len(math_scores)):
    X_og.append([1 if math_scores['school'][i] == 'GP' else 0, 1 if math_scores['sex'][i] == 'F' else 0, math_scores['age'][i], 1 if math_scores['address'][i] == 'U' else 0, 1 if math_scores['famsize'][i] == 'LE3' else 0, 1 if math_scores['Pstatus'][i] == 'T' else 0, math_scores['Medu'][i], math_scores['Fedu'][i], math_scores['traveltime'][i], math_scores['studytime'][i], math_scores['failures'][i], 1 if math_scores['schoolsup'][i] == 'yes' else 0, 1 if math_scores['famsup'][i] == 'yes' else 0, 1 if math_scores['paid'][i] == 'yes' else 0, 1 if math_scores['activities'][i] == 'yes' else 0, 1 if math_scores['nursery'][i] == 'yes' else 0, 1 if math_scores['higher'][i] == 'yes' else 0, 1 if math_scores['internet'][i] == 'yes' else 0, 1 if math_scores['romantic'][i] == 'yes' else 0, math_scores['famrel'][i], math_scores['freetime'][i], math_scores['goout'][i], math_scores['Dalc'][i], math_scores['Walc'][i], math_scores['health'][i], math_scores['absences'][i]])

print(len(X_og))
print(X_og[0])


# manually selected features
# sex - student's sex (binary: 'F' - female or 'M' - male)
# age - student's age (numeric: from 15 to 22)
# address - student's home address type (binary: 'U' - urban or 'R' - rural)
# Pstatus - parent's cohabitation status (binary: 'T' - living together or 'A' - apart)
# Pcollegedegree - Either parent has a college degree
# traveltime - home to school travel time (numeric: 1 - 1 hour)
# studytime - weekly study time (numeric: 1 - 10 hours)
# failures - number of past class failures (numeric: n if 1<=n<3, else 4)
# schoolsup - extra educational support (binary: yes or no)
# famsup - family educational support (binary: yes or no)
# paid - extra paid classes within the course subject (Math or Portuguese) (binary: yes or no)
# activities - extra-curricular activities (binary: yes or no)
# nursery - attended nursery school (binary: yes or no)
# higher - wants to take higher education (binary: yes or no)
# internet - Internet access at home (binary: yes or no)
# romantic - with a romantic relationship (binary: yes or no)
# famrel - quality of family relationships (numeric: from 1 - very bad to 5 - excellent)
# Dalc - workday alcohol consumption (numeric: from 1 - very low to 5 - very high)
# Walc - weekend alcohol consumption (numeric: from 1 - very low to 5 - very high)
# absences - number of school absences (numeric: from 0 to 93)

X_my = []
y_my = avg_scores
my_cols = ['sex', 'age', 'address', 'Pstatus', 'Pcollegedegree', 'traveltime', 'studytime', 'failures', 'schoolsup', 'famsup', 'paid', 'activities', 'nursery', 'higher', 'internet', 'romantic', 'famrel', 'Dalc', 'Walc', 'health', 'absences']
for i in range(len(math_scores)):
    X_my.append([1 if math_scores['sex'][i] == 'F' else 0, math_scores['age'][i], 1 if math_scores['address'][i] == 'U' else 0, 1 if math_scores['Pstatus'][i] == 'T' else 0, Pcollegedegree[i], math_scores['traveltime'][i], math_scores['studytime'][i], math_scores['failures'][i], 1 if math_scores['schoolsup'][i] == 'yes' else 0, 1 if math_scores['famsup'][i] == 'yes' else 0, 1 if math_scores['paid'][i] == 'yes' else 0, 1 if math_scores['activities'][i] == 'yes' else 0, 1 if math_scores['nursery'][i] == 'yes' else 0, 1 if math_scores['higher'][i] == 'yes' else 0, 1 if math_scores['internet'][i] == 'yes' else 0, 1 if math_scores['romantic'][i] == 'yes' else 0, math_scores['famrel'][i], math_scores['Dalc'][i], math_scores['Walc'][i], math_scores['absences'][i]])


# Regression Feature Selection

# pearson's correlation feature selection for numeric input and numeric output

# # generate dataset
# X, y = make_regression(n_samples=100, n_features=100, n_informative=10)
# define feature selection - Select top 10 features
fs = SelectKBest(score_func=f_classif, k=10)
# apply feature selection
X_selected = fs.fit_transform(X_og, y_og)
print(X_selected.shape)
print(X_selected)



# Create and fit selector





# Get columns to keep and create new dataframe with those only
cols = fs.get_support(indices=True)
Selected_features_og = []
for i in cols:
    Selected_features_og.append(og_cols[i])

print(Selected_features_og)

print('\n\nNow for mine:')
X_selected = fs.fit_transform(X_my, y_my)
print(X_selected.shape)
print(X_selected)

print(X_selected[0])
cols = fs.get_support(indices=True)
Selected_features_my = []
for i in cols:
    Selected_features_my.append(my_cols[i])

print(Selected_features_my)

# With regression - ['age', 'address', 'Pcollegedegree', 'traveltime', 'studytime', 'failures', 'schoolsup', 'higher', 'internet', 'romantic']
# With f_classif - ['age', 'address', 'Pstatus', 'Pcollegedegree', 'traveltime', 'failures', 'schoolsup', 'paid', 'higher', 'Walc']

X = []
y = avg_scores
sel_cols = ['age', 'address', 'Pstatus', 'Pcollegedegree', 'traveltime', 'failures', 'schoolsup', 'paid', 'higher', 'Walc']
for i in range(len(math_scores)):
    X.append([math_scores['age'][i], 1 if math_scores['address'][i] == 'U' else 0, 1 if math_scores['Pstatus'][i] == 'T' else 0, Pcollegedegree[i], math_scores['traveltime'][i], math_scores['failures'][i], 1 if math_scores['schoolsup'][i] == 'yes' else 0, 1 if math_scores['paid'][i] == 'yes' else 0, 1 if math_scores['higher'][i] == 'yes' else 0, math_scores['Walc'][i]])





# Cross Validation
#
# # compare different numbers of features selected using mutual information
# from sklearn.datasets import make_regression
# from sklearn.model_selection import RepeatedKFold
# from sklearn.feature_selection import SelectKBest
# from sklearn.feature_selection import mutual_info_regression
# from sklearn.linear_model import LinearRegression
# from sklearn.pipeline import Pipeline
# from sklearn.model_selection import GridSearchCV
# # define dataset
# # X, y = make_regression(n_samples=1000, n_features=100, n_informative=10, noise=0.1, random_state=1)
# # define the evaluation method
# cv = RepeatedKFold(n_splits=10, n_repeats=3, random_state=1)
# # define the pipeline to evaluate
# model = LinearRegression()
# fs = SelectKBest(score_func=mutual_info_regression)
# pipeline = Pipeline(steps=[('sel',fs), ('lr', model)])
# # define the grid
# grid = dict()
# grid['sel__k'] = [i for i in range(len(my_cols))]
# # define the grid search
# search = GridSearchCV(pipeline, grid, scoring='neg_mean_squared_error', n_jobs=-1, cv=cv)
# # perform the search
# results = search.fit(X_my, y_my)
# # summarize best
# print('Best MAE: %.3f' % results.best_score_)
# print('Best Config: %s' % results.best_params_)
# # summarize all
# means = results.cv_results_['mean_test_score']
# params = results.cv_results_['params']
# for mean, param in zip(means, params):
#     print(">%.3f with: %r" % (mean, param))









# Split data
X_t, X_test, y_t, y_test = train_test_split(X, y, test_size=0.20, random_state=42)
X_train, X_val, y_train, y_val = train_test_split(X_t, y_t, test_size=0.125, random_state=42, shuffle=False)


# K-Means clustering

X_Walc = []
for i in range(len(X)):
    X_Walc.append(X[i][9])

X_Walc = np.array(X_Walc).reshape(-1,1)

X_Walc_train, X_Walc_test, y_Walc_train, y_Walc_test = train_test_split(X_Walc, y, test_size=0.20, random_state=42)

for i in range(2, 11):
    km = KMeans(n_clusters=i, random_state=42)
    km.fit_predict(X_Walc_train)
    print('Score - ' , metrics.silhouette_score(X_Walc_train, km.labels_, metric='euclidean'))

# Optimal value - 5

# labels = KMeans(5, random_state=42).fit_predict(X_Walc)
# plt.title('Alcohol Consumption vs. Grades')
# plt.xlabel('Weekend Alcohol Consumption')
# plt.ylabel('Average Grades')
# plt.scatter(X_Walc, y, c=labels, cmap='viridis');
# plt.show()



# Build a predictor with various ML algorithms



# KNN - Does not work on continuous labels

# acc = []
# for i in range(1, 40):
#     neigh = KNeighborsClassifier(n_neighbors=i).fit(X_t, y_t)
#     yhat = neigh.predict(X_test)
#     acc.append(metrics.accuracy_score(y_test, yhat))
#
# plt.figure(figsize=(10, 6))
# plt.plot(range(1, 40), acc, color='blue', linestyle='dashed',
#          marker='o', markerfacecolor='red', markersize=10)
# plt.title('accuracy vs. K Value')
# plt.xlabel('K')
# plt.ylabel('Accuracy')
# print("Maximum accuracy:-", max(acc), "at K =", acc.index(max(acc)))

# acc = []
# for i in range(2, 40):
#     neigh = KNeighborsRegressor(n_neighbors=i).fit(X_t, y_t)
#     yhat = neigh.predict(X_test)
#     acc.append(metrics.mean_squared_error(y_test, yhat, squared=False))
#
# plt.figure(figsize=(10, 6))
# plt.plot(range(2, 40), acc, color='blue', linestyle='dashed',
#          marker='o', markerfacecolor='red', markersize=10)
# plt.title('accuracy vs. K Value')
# plt.xlabel('K')
# plt.ylabel('Accuracy')
# plt.show()
# print("Maximum accuracy:-", max(acc), "at K =", acc.index(max(acc)))


neigh = KNeighborsRegressor(n_neighbors=3).fit(X_t, y_t)
print('Score of KNN - ', neigh.score(X, y))


# Naive Bayes
# gnb = GaussianNB()
# # print(len(test_X), " ", len(X_test))
# y_pred = gnb.fit(X_train, y_train).predict(X_val)
# print("Naive Bayes Accuracy - ", metrics.accuracy_score(y_val, y_pred))
# print('Naive Bayes score - ', gnb.score(X, y))





# Decision Tree
# clf = tree.DecisionTreeClassifier()
# clf.fit(X_train, y_train)
# y_pred = clf.predict(X_val)
# print('Decision Tree Accuracy - ', metrics.accuracy_score(y_val, y_pred))
# print('Decision Tree Score - ', clf.score(X, y))

# Random Forest
fst = RandomForestRegressor(max_depth=2, random_state=42)
fst.fit(X_train, y_train)
y_hat = fst.predict(X_val)
# print('Random FOrest Accuracy - ', metrics.accuracy_score(y_val, y_hat))
count = 0
for i in range(len(y_val)):
    if y_val[i] == y_hat[i]:
        count += 1
print('Random Forest Accuracy - ', (count*100)/len(y_hat))
print('Random FOrest Score - ', fst.score(X, y))


# tune it now

max_d = 0
max_Score = -1
for i in range(2, 101):
    fst = RandomForestRegressor(max_depth=i, random_state=42)
    fst.fit(X_train, y_train)
    s = fst.score(X, y)
    if max_Score < s:
        max_Score = s
        max_d = i

print(max_d, ' ', max_Score)    # 14  0.48307565307368794

max_n = 0
max_Score = -1
for i in range(2, 101):
    fst = RandomForestRegressor(max_depth=max_d, n_estimators=i, random_state=42)
    fst.fit(X_train, y_train)
    s = fst.score(X, y)
    if max_Score < s:
        max_Score = s
        max_n = i

print(max_n, ' ', max_Score)    # 35 0.48872264436934965

# Accuracy
fst = RandomForestRegressor(max_depth=max_d, n_estimators=max_n, random_state=42)
fst.fit(X_t, y_t)
y_hat = fst.predict(X_test)
print('Random forest accuracy - ', metrics.mean_squared_error(y_test, y_hat, squared=False))


# Results
fst = RandomForestRegressor(max_depth=max_d, n_estimators=max_n, random_state=42)
fst.fit(X_train, y_train)
y_preds = fst.predict(X_test)

print(y_preds)
print(y_test)
print('RMSE value - ', metrics.mean_squared_error(y_test, y_preds, squared=False))

xaxis = [*range(1, len(y_test)+1, 1)]
X_axis = [*range(1, len(y)+1, 1)]

# plt.scatter(X_axis, y)
plt.plot(xaxis, y_test, 'c', label='Actual Scores')
plt.plot(xaxis, y_preds, 'r', label='Predicted Scores')
plt.ylabel("Average Score")
plt.legend(loc="lower right")
plt.title('RandomForestRegressor model results')
plt.show()



print('results:-')
print(y_test)
print(y_preds)


rmse = metrics.mean_squared_error(y_test, y_preds, squared=False)

for i in range(len(y_preds)):
    y_preds[i] += rmse

plt.plot(xaxis, y_test, 'r', label='Actual Scores')
plt.plot(xaxis, y_preds, 'y', label='Predicted Scores with RMSE correction')
plt.ylabel("Average Score")
plt.legend(loc="lower right")
plt.title('RandomForestRegressor model results with RMSE correction')

plt.show()


# boostingregressor
# max_n = 0
# max_d = 0
# max_Score = -1
# max_err = -1
# for i in range(2, 101):
#     for j in range(2, 101):
#         bst = GradientBoostingRegressor(n_estimators=i, max_depth=j, learning_rate=0.1, random_state=42, loss='ls').fit(X_train, y_train)
#         y_pred = bst.predict(X_val)
#         sre = bst.score(X,y)
#         rmse = metrics.mean_squared_error(y_val, y_pred)
#         if max_Score < sre and max_err < rmse:
#             max_Score = sre
#             max_err = rmse
#             max_n = i
#             max_d = j

max_d = 0
max_Score = -1
max_err = -1
for i in range(2, 101):
    bst = GradientBoostingRegressor(max_depth=i, learning_rate=0.1, random_state=42, loss='ls').fit(X_train, y_train)
    bst.fit(X_train, y_train)
    s = bst.score(X, y)
    y_pred = bst.predict(X_val)
    rmse = metrics.mean_squared_error(y_val, y_pred, squared=False)
    if max_Score < s and max_err < rmse:
        max_Score = s
        max_err = rmse
        max_d = i

print(max_d, ' ', max_Score, ' ', max_err)    # 14  0.48307565307368794


max_n = 0
max_Score = -1
max_err = -1
for i in range(2, 101):
    bst = GradientBoostingRegressor(max_depth=max_d, n_estimators=i, learning_rate=0.1, random_state=42, loss='ls').fit(X_train, y_train)
    bst.fit(X_train, y_train)
    s = bst.score(X, y)
    y_pred = bst.predict(X_val)
    rmse = metrics.mean_squared_error(y_val, y_pred, squared=False)
    if max_Score < s and max_err < rmse:
        max_Score = s
        max_err = rmse
        max_n = i



print(max_Score, ' ', max_n, ' ', max_err, ' ', max_d)


# Random Forest Regressor has the best performance


# NN -- not implemented
#
# print('starting NN')
#
# scaler = MinMaxScaler(feature_range=(-1, 1))
# train_data_normalized = scaler.fit_transform(X_train)
# test_data_normalized = scaler.fit_transform(X_test)
#
# train_data_normalized = torch.FloatTensor(train_data_normalized).view(-1)
# test_data_normalized = torch.FloatTensor(test_data_normalized).view(-1)
#
#
# train_window = len(X_train)
#
# def create_inout_sequences(input_data, tw):
#     inout_seq = []
#     L = len(input_data)
#     for i in range(L-tw):
#         train_seq = input_data[i:i+tw]
#         train_label = input_data[i+tw:i+tw+1]
#         inout_seq.append((train_seq ,train_label))
#     return inout_seq
#
#
# train_inout_seq = create_inout_sequences(train_data_normalized, train_window)
# test_inout_seq = create_inout_sequences(test_data_normalized, len(X_test))
#
# print('starting LSTM')
#
#
# class LSTM(nn.Module):
#     def __init__(self, input_size=1, hidden_layer_size=100, output_size=1):
#         super().__init__()
#         self.hidden_layer_size = hidden_layer_size
#
#         self.lstm = nn.LSTM(input_size, hidden_layer_size)
#
#         self.linear = nn.Linear(hidden_layer_size, output_size)
#
#         self.hidden_cell = (torch.zeros(1,1,self.hidden_layer_size),
#                             torch.zeros(1,1,self.hidden_layer_size))
#
#     def forward(self, input_seq):
#         lstm_out, self.hidden_cell = self.lstm(input_seq.view(len(input_seq) ,1, -1), self.hidden_cell)
#         predictions = self.linear(lstm_out.view(len(input_seq), -1))
#         return predictions[-1]
#
# print('defining model')
#
#
# device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
# print(device)
#
# model = LSTM()
# model.to(device)
# loss_function = nn.MSELoss()
# optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
#
# epochs = 1
#
# print('\n\nTRAINING\n')
#
# for i in range(1, epochs+1):
#     print('In - ', i)
#     for seq, labels in train_inout_seq:
#         optimizer.zero_grad()
#         model.hidden_cell = (torch.zeros(1, 1, model.hidden_layer_size),
#                         torch.zeros(1, 1, model.hidden_layer_size))
#
#         y_pred = model(seq)
#
#         single_loss = loss_function(y_pred, labels)
#         single_loss.backward()
#         optimizer.step()
#
#     if i%10 == 1:
#         print(f'epoch: {i:3} loss: {single_loss.item():10.8f}')
#
# print(f'epoch: {i:3} loss: {single_loss.item():10.10f}')
#
# model.eval()
# predictions = []
# for i in range(len(X_test)):
#     seq = torch.FloatTensor(test_inout_seq)
#     with torch.no_grad():
#         model.hidden = (torch.zeros(1, 1, model.hidden_layer_size),
#                         torch.zeros(1, 1, model.hidden_layer_size))
#         predictions.append(model(seq).item())
#
# actual_predictions = scaler.inverse_transform(np.array(predictions).reshape(-1, 1))
# print(actual_predictions)